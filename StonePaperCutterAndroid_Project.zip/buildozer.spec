[app]
title = Stone Paper Cutter
package.name = stonepapercutter
package.domain = org.example
source.dir = .
source.include_exts = py,png,jpg,kv,atlas
version = 1.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0

# Android settings
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

# Keep the app simple: no permissions are needed for this game.
android.permissions =

[buildozer]
log_level = 2
warn_on_root = 1
