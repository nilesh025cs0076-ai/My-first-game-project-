# Stone Paper Cutter — Android APK project

This project converts the original Tkinter game into a touch-friendly Android app using Kivy.

## Game rules preserved
- Stone beats Cutter.
- Paper beats Stone.
- Cutter beats Paper.
- Same choice is a draw.
- The computer chooses randomly.

## Easiest beginner route: build the APK using GitHub Actions

You need a GitHub account and this project ZIP.

1. Extract this ZIP on your computer.
2. Create a new repository on GitHub (for example, `stone-paper-cutter-android`).
3. Upload the extracted project files and folders to the repository. Make sure `.github/workflows/build-apk.yml` is included.
4. Open the repository's **Actions** tab.
5. If GitHub asks, enable Actions for the repository.
6. Select **Build Android APK** in the left menu.
7. Press **Run workflow**, then the green **Run workflow** button.
8. Wait for the workflow to finish successfully.
9. Open the completed workflow run. Under **Artifacts**, download `StonePaperCutter-debug-APK`.
10. Extract the downloaded artifact ZIP to get the `.apk` file.
11. Transfer the APK to your Android phone, open it, and follow Android's prompt to allow installation from that source if needed.

The workflow builds a **debug APK** for testing/personal use. It is not a Play Store release build.

## Build locally (Linux)

Install Java 17, Python 3, the Android build dependencies, then run:

```bash
python3 -m pip install --user buildozer cython
buildozer -v android debug
```

The first build downloads Android SDK/NDK components and can take a while. The APK should be created in the `bin/` folder.

## Files
- `main.py` — Kivy app and game logic.
- `buildozer.spec` — Android packaging settings.
- `.github/workflows/build-apk.yml` — cloud build workflow.

No camera, location, internet, or other permissions are needed by the game.
