import random
from kivy.app import App
from kivy.core.window import Window
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.widget import Widget

# Same rules as the original Tkinter game:
# Stone beats Cutter, Paper beats Stone, Cutter beats Paper.
CHOICES = {"s": 1, "p": -1, "c": 0}
CHOICE_NAMES = {1: "Stone", -1: "Paper", 0: "Cutter"}
WINNING_PAIRS = {(1, 0), (-1, 1), (0, -1)}


class StonePaperCutterApp(App):
    def build(self):
        self.title = "Stone Paper Cutter"
        Window.clearcolor = (0.68, 0.87, 0.95, 1)

        root = BoxLayout(
            orientation="vertical",
            padding=[dp(22), dp(28), dp(22), dp(24)],
            spacing=dp(14),
        )

        root.add_widget(Widget(size_hint_y=0.25))

        heading = Label(
            text="[b]STONE PAPER CUTTER[/b]",
            markup=True,
            font_size=sp(27),
            color=(0.08, 0.16, 0.25, 1),
            size_hint_y=None,
            height=dp(62),
        )
        root.add_widget(heading)

        self.user_label = Label(
            text="You chose: -",
            font_size=sp(19),
            color=(0.08, 0.16, 0.25, 1),
            size_hint_y=None,
            height=dp(42),
        )
        root.add_widget(self.user_label)

        self.computer_label = Label(
            text="Computer chose: -",
            font_size=sp(19),
            color=(0.08, 0.16, 0.25, 1),
            size_hint_y=None,
            height=dp(42),
        )
        root.add_widget(self.computer_label)

        self.result_label = Label(
            text="[b]Choose your move![/b]",
            markup=True,
            font_size=sp(23),
            color=(0.85, 0.45, 0.05, 1),
            size_hint_y=None,
            height=dp(60),
        )
        root.add_widget(self.result_label)

        root.add_widget(Widget(size_hint_y=0.08))

        button_specs = [
            ("Stone  🪨", "s"),
            ("Paper  📄", "p"),
            ("Cutter  ✂️", "c"),
        ]
        for caption, choice in button_specs:
            button = Button(
                text=caption,
                font_size=sp(20),
                bold=True,
                size_hint_y=None,
                height=dp(62),
                background_normal="",
                background_color=(0.12, 0.36, 0.62, 1),
                color=(1, 1, 1, 1),
            )
            button.bind(on_release=lambda instance, c=choice: self.play_game(c))
            root.add_widget(button)

        root.add_widget(Widget(size_hint_y=0.35))
        return root

    def play_game(self, user_choice):
        computer = random.choice(list(CHOICE_NAMES.keys()))
        you = CHOICES[user_choice]

        self.user_label.text = f"You chose: {CHOICE_NAMES[you]}"
        self.computer_label.text = f"Computer chose: {CHOICE_NAMES[computer]}"

        if you == computer:
            self.result_label.text = "[b]It's a draw![/b]"
            self.result_label.color = (0.85, 0.45, 0.05, 1)
        elif (you, computer) in WINNING_PAIRS:
            self.result_label.text = "[b]You win![/b]"
            self.result_label.color = (0.05, 0.48, 0.20, 1)
        else:
            self.result_label.text = "[b]You lose![/b]"
            self.result_label.color = (0.75, 0.10, 0.12, 1)


if __name__ == "__main__":
    StonePaperCutterApp().run()
